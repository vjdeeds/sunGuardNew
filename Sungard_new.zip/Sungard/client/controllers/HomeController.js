/**
 * Created by Taru on 24-07-2015.
 */
Sungard.controller('HomeController', function HomeController($scope,$location,$http) {

    $scope.showForm = false;

    //call to get product details
    $scope.getProduct = function(){
        if($scope.searchProduct != null)
        {
            $http.get('/getResult',{params: { Name: $scope.searchProduct}})
                .success(function (data){
                    $scope.productID = data._id;
                    $scope.productQuantity = data.Quantity;
                    $scope.productName = data.Name;
                    $scope.productCP = data.Cost;
                    $scope.productSP = data.SellingPrice;
                    if($scope.productID!= null)
                    {
                        $scope.showForm = true;
                    }
                })
                .error(function(data, status) {
                    alert('Error! ' + status + ' : ' + data)
                });
        }
        else{
            alert("Enter a valid product name");
        }
    };

    $scope.updateProduct = function(){
        if($scope.productSP<$scope.productCP){
            alert("Enter a selling price greater than cost price")
        }
        else {
            $http.post('/updateProduct', {
                Name: $scope.productName,
                Id: $scope.productID,
                SellingPrice: $scope.productSP
            }).
                success(function (data) {
                    alert("Product Successfully Updated!");
                }).
                error(function (data, status) {
                    alert(status);
                });
        }
    };

});