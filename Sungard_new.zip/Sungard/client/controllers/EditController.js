/**
 * Created by Vijay on 24-07-2015.
 */
Sungard.controller('EditController', function EditController($scope,$location,$http) {
    $scope.saveProduct = function(){
        if($scope.productSP<$scope.productCP){
            alert("Enter a selling price greater than cost price")
        }
        else {
            $http.post('/saveProduct', {
                Name: $scope.productName,
                Quantity: $scope.productQuantity,
                Cost: $scope.productCP,
                SellingPrice: $scope.productSP
            }).
                success(function (data) {
                    alert("Product Successfully Saved!");
                }).
                error(function (data, status) {
                    alert(status);
                });
        }
    };
});
