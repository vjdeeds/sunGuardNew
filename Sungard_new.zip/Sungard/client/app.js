/**
 * Created by Taru on 24-07-2015.
 */

var Sungard = angular.module('Sungard',['ngRoute']).run(function($rootScope,$location) {
    $rootScope.home = function(){
        $location.path('/HomePage');
    };
    $rootScope.add = function(){
        $location.path('/EditPage');
    };
});

Sungard.config(function($routeProvider){
    $routeProvider.when('/',{
        templateUrl: 'views/HomePage.html'
    }).
        when('/EditPage',{
            templateUrl: 'views/EditPage.html'
        })
        .otherwise({
            redirectTo: '/'
        })
})
