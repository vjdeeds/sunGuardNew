/**
 * Created by Taru on 01-08-2015.
 */

Sungard.directive('autoComplete', function($http){
    return{
        restrict:'A',
        scope:{ngModel : '='},
        require: 'ngModel',
        link: function(scope,elem,attrb){
            elem.autocomplete({
                minLength:2,
                source: function(req,resp){
                    $http.get('/getProdNames')
                        .success(function (data) {
                            if (data.length > 0) {
                                var nameArray = [];
                                for (var i = 0; i < data.length; i++) {
                                    if (data[i].Name.toLowerCase().indexOf(req.term)!= -1 || data[i].Name.indexOf(req.term)!= -1)
                                    {
                                        nameArray.push(data[i].Name)
                                    }
                                    resp(nameArray);
                                }
                            }
                        })
                        .error(function (data, status) {
                            alert('Error! ' + status + ' : ' + data)
                        });
                },
                select: function(ev,ui){
                        scope.ngModel = ui.item.value;
                }
            });
        }
    }
})
