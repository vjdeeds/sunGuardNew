/**
 * Created by Vijay on 24-07-2015.
 */
var express = require('express');
var bodyParser = require("body-parser");
var ejs = require('ejs');
var path = require("path");
var mongoose = require('mongoose');
var app = express();

//Set environment variables
app.set('views', __dirname + '/client');
app.engine('html',ejs.renderFile);
app.set('view engine', 'html');
app.use(express.static(path.join(__dirname + '/client')));
app.use(bodyParser.json()); // for parsing application/json
app.use(bodyParser.urlencoded({extended:true}));


//Database configuration
var db = mongoose.connection;
mongoose.connect('mongodb://localhost:27017/ProductDetails');
var productDetailsSchema = mongoose.Schema({
        Name:String,
        Quantity:Number,
        Cost:Number,
        SellingPrice:Number
});
var Product = mongoose.model('Product', productDetailsSchema);

//handle get method to get the matching product name
app.get('/getResult',function(req,res) {
    Product.findOne({ Name: req.query.Name }, function(err, item) {
        if (err){
            return console.error(err);
        }
        else{
            console.log(item);
            res.send(item)
        }
    });
});

//handle get method to get all the product names
app.get('/getProdNames',function(req,res) {
    var query = Product.find({}).select('Name -_id');
    query.exec(function (err, item) {
        if (err) {
            return next(err);
        }
        else {
            res.send(item)
        }
    });
});

//handle post method to update product to database
app.post('/updateProduct',function(req,res){

    var Id = req.body.Id;
    var Name = req.body.Name;
    var SellingPrice = req.body.SellingPrice;

    Product.findById(Id, function (err, prod) {
        if (err) {
            return handleError(err);
        }
        else {
            console.log(prod.Name);
            prod.Name = Name;
            prod.SellingPrice = SellingPrice;
            prod.save(function (err) {
                if (err) {
                    return handleError(err);
                }
                else {
                    res.send(prod);
                }
            });
        }
    });

    //res.send(req.body);
});

//handle post method to save product to database
app.post('/saveProduct',function(req,res){
    var Name = req.body.Name;
    var Quantity = req.body.Quantity;
    var Cost = req.body.Cost;
    var SellingPrice = req.body.SellingPrice;

    var laptop = new Product({
        Name: Name
        , Quantity: Quantity
        , Cost: Cost
        , SellingPrice: SellingPrice
    });

    laptop.save(function(err,laptop){
        if (err) {
            console.log("There was an error!!");
        }
        else
        {
            console.log(laptop);
        }
    })

    res.send(req.body);
});

app.get('*',function(req,res){
    res.render("Home");
});

app.listen('3030');
console.log("server up at 3030");
